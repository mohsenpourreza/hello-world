function [SimRR] = AFFDEF(Pars,Extra)
% Reading and substituting new file scein
    fid = fopen('scein.dat', 'r');
    mat1= fgetl(fid);%first line of file scein
    mat1=str2num(mat1);
    mat2= fgetl(fid);%second line of file scein
    mat2=str2num(mat2);
    mat3= fgetl(fid); 
    mat3=str2num(mat3);
    mat4= fgetl(fid); 
    mat4=str2num(mat4);
    mat5= fgetl(fid); 
    mat5=str2num(mat5);
    mat6= fgetl(fid); 
    mat6=str2num(mat6);
    mat7= fgetl(fid); 
    mat7=str2num(mat7);
    mat8= fgetl(fid); 
    mat8=str2num(mat8);
    mat9= fgetl(fid); 
    mat9=str2num(mat9);
    mat10= fgetl(fid);
    mat10=str2num(mat10);
    mat11= fgetl(fid); 
    mat11=str2num(mat11);

    fclose(fid);
    mat3(1)=Pars(1,1);
    mat4(1)=Pars(1,2);
    mat5(1)=Pars(1,3);
    mat6(1)=Pars(1,4);
    mat7(1)=Pars(1,5);
    mat8(1)=Pars(1,6);
    mat9(1)=Pars(1,7);
    mat10(1)=Pars(1,8);
    mat11(1)=Pars(1,9);

    fid = fopen('scein.dat', 'wt');
    format short;
    fprintf(fid, '%5g%5g%5.2f%5g%5g%5g', mat1);
    fprintf(fid, '\n');
    fprintf(fid, '%5g%5g%5g%5g%5g%5g', mat2);
    fprintf(fid, '\n');
    fprintf(fid,'%10.3g', mat3);
    fprintf(fid, '\n');
    fprintf(fid, '%10.1f', mat4);
    fprintf(fid, '\n');
    fprintf(fid, '%10.2g', mat5);
    fprintf(fid, '\n');
    fprintf(fid, '%10.2g', mat6);
    fprintf(fid, '\n');
    fprintf(fid, '%10.5g', mat7);
    fprintf(fid, '\n');
    fprintf(fid, '%10.3g', mat8);
    fprintf(fid, '\n');
    fprintf(fid, '%10.1f', mat9);
    fprintf(fid, '\n');
    fprintf(fid, '%10.3g', mat10);
    fprintf(fid, '\n');
    fprintf(fid, '%10.3g', mat11);
    fprintf(fid, '\n');

    fclose(fid);
    % Call model to generate simulated data
    dos affdef;
    
    %evalstr = ['ModPred = ',ModelName,'(x(ii,:),Extra);']; eval(evalstr);
    ModPred=dlmread('outlet.out');
    SimRR=ModPred(:,2);